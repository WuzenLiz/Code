from collections import defaultdict as dictlist

if __name__ == "__main__":
    