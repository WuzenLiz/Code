#import
import json as json

#Define 
data = None
INPUTfile = 'data.json'
OUTPUTJsonfile = 'Dumped.json'
OUTPUTExelfile = 'Dumped.xlsx'

#file function
def Op_File(file):
    with open(file, encoding="utf8") as json_file:
        data = json.load(json_file)
    return data

def Sv_file(file,data):  
    with open(file, 'w'  ,encoding ="utf8") as outfile:
        json.dump(data, outfile)
        print(len(data))
def convert_to_exel(infile,outfile):
    import pandas as pd
    df_json = pd.read_json(infile)
    df_json.to_excel(outfile)

#Main function
def removeduplicate(data):
    seen = []
    for item in data:
        if item not in seen:
            seen.append(item)
    return seen

def main():
    data = Op_File(INPUTfile)
    opdata = removeduplicate(data)
    Sv_file(OUTPUTJsonfile,opdata)
    convert_to_exel(OUTPUTJsonfile,OUTPUTExelfile)  

if __name__ == '__main__':
    main()
    print("DONE")
    
    
        
